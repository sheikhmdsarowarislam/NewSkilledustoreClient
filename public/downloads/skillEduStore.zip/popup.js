// popup.js

document.getElementById('cleanupBtn').addEventListener('click', function() {
    const button = this;
    const status = document.getElementById('status');
    
    // Disable button and show loading
    button.disabled = true;
    button.textContent = 'Cleaning...';
    status.className = '';
    status.style.display = 'none';
    
    // Send cleanup message to background
    chrome.runtime.sendMessage({ type: 'cleanup' }, (response) => {
        button.disabled = false;
        button.textContent = 'Clear All Sessions';
        
        if (chrome.runtime.lastError) {
            status.className = 'error';
            status.textContent = 'Error: ' + chrome.runtime.lastError.message;
        } else if (response && response.success) {
            status.className = 'success';
            status.textContent = 'All sessions cleared successfully!';
            
            // Hide success message after 3 seconds
            setTimeout(() => {
                status.style.display = 'none';
            }, 3000);
        } else {
            status.className = 'error';
            status.textContent = 'Failed to clear sessions';
        }
    });
});