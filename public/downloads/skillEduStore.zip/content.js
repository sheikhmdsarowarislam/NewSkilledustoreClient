// content.js - Clean Version Without Error Messages

console.log('🚀 Extension content script loaded');

// Mark extension as installed for panel detection
window.__EXTENSION_INSTALLED__ = true;

// Notify panel immediately
window.postMessage({ 
    type: 'EXTENSION_STATUS', 
    installed: true 
}, '*');

console.log('✅ Extension marker set: window.__EXTENSION_INSTALLED__ = true');

/**
 * 🚫 Block specific URLs
 */
const blockedUrls = [
    'https://gale.udemy.com/message/',
    // 'https://gale.udemy.com/user/edit-profile/',
    'https://gale.udemy.com/user/edit-account/',
    'https://gale.udemy.com/user/edit-photo/',
    'https://gale.udemy.com/user/logout/'
    // Add more URLs here if needed
];

function blockLinks() {
    // Block all <a> tags with blocked URLs
    const links = document.querySelectorAll('a');
    links.forEach(link => {
        const href = link.href;
        if (blockedUrls.some(blocked => href.includes(blocked))) {
            link.style.pointerEvents = 'none';
            link.style.opacity = '0.5';
            link.style.cursor = 'not-allowed';
            
            link.addEventListener('click', function(e) {
                e.preventDefault();
                e.stopPropagation();
                alert('⚠️ Access to this page is restricted!');
                return false;
            }, true);
        }
    });
    
    // Block direct navigation
    blockedUrls.forEach(blockedUrl => {
        if (window.location.href.includes(blockedUrl)) {
            alert('⚠️ Access to this page is restricted!');
            window.history.back();
        }
    });
}

// Run on page load
window.addEventListener('load', blockLinks);
// Run periodically to catch dynamically added links
setInterval(blockLinks, 1000);
// Run on DOM changes
const linkObserver = new MutationObserver(blockLinks);
linkObserver.observe(document.body, { childList: true, subtree: true });

/**
 * Hide extension reload button on chrome://extensions page
 */
function hideReloadButton() {
    if (window.location.href.includes('chrome://extensions')) {
        const style = document.createElement('style');
        style.textContent = `
            button[aria-label*="Reload" i],
            button[title*="Reload" i],
            #reload-button,
            .reload-extension,
            extensions-item #dev-reload-button,
            [id*="reload" i] {
                display: none !important;
                visibility: hidden !important;
                pointer-events: none !important;
                opacity: 0 !important;
            }
        `;
        document.head.appendChild(style);
        
        setInterval(() => {
            const reloadButtons = document.querySelectorAll('button[aria-label*="Reload" i], button[title*="Reload" i], #reload-button, .reload-extension');
            reloadButtons.forEach(btn => {
                btn.style.display = 'none';
                btn.style.visibility = 'hidden';
                btn.style.pointerEvents = 'none';
                btn.disabled = true;
            });
        }, 500);
    }
}

hideReloadButton();

/**
 * Show toast notification
 */
function showToast(message, type = 'info') {
    const existingToast = document.getElementById('extension-toast');
    if (existingToast) {
        existingToast.remove();
    }
    
    const toast = document.createElement('div');
    toast.id = 'extension-toast';
    toast.textContent = message;
    
    const styles = {
        info: { bg: '#2196F3', icon: 'ℹ️' },
        success: { bg: '#4CAF50', icon: '✓' },
        warning: { bg: '#ff9800', icon: '⚠️' }
    };
    
    const style = styles[type] || styles.info;
    
    toast.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        background: ${style.bg};
        color: white;
        padding: 16px 24px;
        border-radius: 8px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.3);
        z-index: 999999;
        font-family: Arial, sans-serif;
        font-size: 14px;
        font-weight: 500;
        max-width: 350px;
        animation: slideIn 0.3s ease-out;
        display: flex;
        align-items: center;
        gap: 10px;
    `;
    
    const icon = document.createElement('span');
    icon.textContent = style.icon;
    icon.style.fontSize = '18px';
    toast.insertBefore(icon, toast.firstChild);
    
    const styleSheet = document.createElement('style');
    styleSheet.textContent = `
        @keyframes slideIn {
            from {
                transform: translateX(400px);
                opacity: 0;
            }
            to {
                transform: translateX(0);
                opacity: 1;
            }
        }
        @keyframes slideOut {
            from {
                transform: translateX(0);
                opacity: 1;
            }
            to {
                transform: translateX(400px);
                opacity: 0;
            }
        }
    `;
    document.head.appendChild(styleSheet);
    
    document.body.appendChild(toast);
    
    setTimeout(() => {
        toast.style.animation = 'slideOut 0.3s ease-in';
        setTimeout(() => toast.remove(), 300);
    }, 4000);
}

/**
 * Check if extension is active
 */
function isExtensionActive() {
    try {
        if (chrome && chrome.runtime && chrome.runtime.id) {
            return true;
        }
    } catch (e) {
        return false;
    }
    return false;
}

/**
 * Hide settings elements
 */
function hideSettings() {
    const settingsSelectors = [
        '.settings', 
        '#settings', 
        '.account-settings', 
        '.my-gpts', 
        '.your-account', 
        '#log-out',
        '.profiles', 
        '.signout', 
        '.logout', 
        '.user-menu', 
        '.menu-settings',
        '[aria-label*="settings" i]',
        // '[aria-label*="account" i]',
        '[aria-label*="logout" i]',
        '[aria-label*="sign out" i]',
        'a[href*="logout"]',
        'a[href*="signout"]',
        'button[data-action*="logout"]',
        'button[data-action*="signout"]',
        '.reset',
        '.interactable',
        '.PuABGQ',
        '.g_id_signout',
        '#radix-_R_7paqpe5q4mj5_',
        '.css-17hg8z'
        

    ];
    
    settingsSelectors.forEach(selector => {
        try {
            const elements = document.querySelectorAll(selector);
            elements.forEach(element => {
                element.style.display = 'none';
                element.style.visibility = 'hidden';
                element.style.opacity = '0';
                element.style.pointerEvents = 'none';
            });
        } catch (e) {
            // Ignore selector errors
        }
    });
}

window.addEventListener('load', hideSettings);
setInterval(hideSettings, 1500);

const observer = new MutationObserver(hideSettings);
observer.observe(document.body, { childList: true, subtree: true });

/**
 * Setup access buttons
 */
function setupAccessButtons() {
    const accessButtons = document.querySelectorAll('button[id*="Cookies"]');
    
    if (accessButtons.length > 0) {
        accessButtons.forEach(button => {
            if (button.dataset.listenerAttached) return;
            button.dataset.listenerAttached = 'true';
            
            button.addEventListener('click', function(event) {
                event.preventDefault();
                event.stopPropagation();
                
                if (!isExtensionActive()) {
                    showToast('⚠️ Please install or activate our extension first!', 'warning');
                    return;
                }
                
                const websiteName = event.target.id.replace("Cookies", "");
                console.log(`Button clicked for: ${websiteName}`);
                
                const originalText = button.textContent;
                const originalDisabled = button.disabled;
                button.textContent = '⏳ Loading...';
                button.disabled = true;
                
                fetch(`https://skilledustoresecurepanel.skilledustore.com/dist/php/custom.php?website=${websiteName}`, {
                    method: 'GET',
                    headers: {
                        'Accept': 'application/json'
                    }
                })
                    .then(response => {
                        if (!response.ok) {
                            return;
                        }
                        return response.json();
                    })
                    .then(data => {
                        if (!data || !data.url || !data.cookies) {
                            button.textContent = originalText;
                            button.disabled = originalDisabled;
                            return;
                        }
                        
                        console.log("✓ Session data received");
                        
                        try {
                            chrome.runtime.sendMessage({
                                type: 'processSessionData',
                                sessionData: {
                                    url: data.url,
                                    cookies: data.cookies
                                }
                            }, response => {
                                if (response && response.success) {
                                    showToast('✓ Session created! Opening in new tab...', 'success');
                                }
                                
                                button.textContent = originalText;
                                button.disabled = originalDisabled;
                            });
                        } catch (e) {
                            button.textContent = originalText;
                            button.disabled = originalDisabled;
                        }
                    })
                    .catch(() => {
                        button.textContent = originalText;
                        button.disabled = originalDisabled;
                    });
            });
        });
        
        console.log(`✓ Setup complete for ${accessButtons.length} button(s)`);
    } else {
        setTimeout(setupAccessButtons, 500);
    }
}

setupAccessButtons();
setInterval(setupAccessButtons, 3000);

/**
 * Listen for messages from admin panel
 */
window.addEventListener('message', function(event) {
    // Only accept messages from same window
    if (event.source !== window) return;

    console.log('📩 Content script received message:', event.data.type);

    // Panel checking if extension is installed
    if (event.data.type === 'CHECK_EXTENSION') {
        console.log('✅ Responding to extension check');
        window.postMessage({ 
            type: 'EXTENSION_STATUS', 
            installed: true 
        }, '*');
    }

    // Panel wants to get current status
    if (event.data.type === 'GET_STATUS') {
        console.log('📊 Getting extension status');
        try {
            chrome.runtime.sendMessage({ type: 'getStatus' }, response => {
                if (!chrome.runtime.lastError && response) {
                    console.log('✅ Status response:', response);
                    window.postMessage({ 
                        type: 'STATUS_RESPONSE', 
                        response: response 
                    }, '*');
                }
            });
        } catch (e) {
            // Silently ignore
        }
    }

    // Panel wants to setup session
    if (event.data.type === 'SETUP_SESSION' && event.data.sessionData) {
        console.log('🚀 Setting up session:', event.data.sessionData);
        try {
            chrome.runtime.sendMessage({
                type: 'processSessionData',
                sessionData: event.data.sessionData
            }, response => {
                if (!chrome.runtime.lastError && response) {
                    console.log('✅ Setup response:', response);
                    window.postMessage({ 
                        type: 'SETUP_RESPONSE', 
                        response: response 
                    }, '*');
                }
            });
        } catch (e) {
            // Silently ignore
        }
    }

    // Panel wants to cleanup session
    if (event.data.type === 'CLEANUP_SESSION') {
        console.log('🧹 Cleaning up session');
        try {
            chrome.runtime.sendMessage({ type: 'cleanup' }, response => {
                if (!chrome.runtime.lastError && response) {
                    console.log('✅ Cleanup response:', response);
                    window.postMessage({ 
                        type: 'CLEANUP_RESPONSE', 
                        response: response 
                    }, '*');
                }
            });
        } catch (e) {
            // Silently ignore
        }
    }
});

// Periodically announce extension presence
setInterval(() => {
    if (isExtensionActive()) {
        window.__EXTENSION_INSTALLED__ = true;
    }
}, 2000);

console.log('✅ Content script fully initialized');