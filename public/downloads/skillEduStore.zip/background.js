const REQUIRED_PERMISSIONS = Object.freeze([
    'cookies',
    'declarativeNetRequest',
    'declarativeNetRequestFeedback',
    'storage',
    'tabs',
    'management',
    'notifications'
]);
const SPECIAL_DOMAINS = Object.freeze([
    'grammarly.com',
    'gemini.google.com',
    'linkedin.com',
    'educative.io',
    'coursera.org',
    'duolingo.com',
    'grok.com',
    'semrush.com',
    'sketchgeniusapp.com',
    'academiscan.com',
    'rewritify.ai',
    'app.wordtune.com'
]);
const COMPETITOR_KEYWORDS = Object.freeze([
    'cookie', 'cookies', 'session', 'auth', 
    'editor', 'inject', 'manager', 'swap'
]);
let INITIAL_FUNCTION_STATE = null;
function initializeFunctionState() {
    try {
        INITIAL_FUNCTION_STATE = {
            setupSession: setupSession.toString(),
            clearDomainCookies: clearDomainCookies.toString(),
            setupHeaderRules: setupHeaderRules.toString(),
            cleanupSession: cleanupSession.toString(),
            checkCompetitorExtensions: checkCompetitorExtensions.toString(),
            setDirectCookies: setDirectCookies.toString(),
            initializeFunctionState: initializeFunctionState.toString(),
            checkRequiredPermissions: checkRequiredPermissions.toString(),
            verifyExtensionIntegrity: verifyExtensionIntegrity.toString(),
            verifyConstants: verifyConstants.toString()
        };
        const constantsChecksum = generateChecksum(JSON.stringify({
            REQUIRED_PERMISSIONS: Array.from(REQUIRED_PERMISSIONS),
            SPECIAL_DOMAINS: Array.from(SPECIAL_DOMAINS),
            COMPETITOR_KEYWORDS: Array.from(COMPETITOR_KEYWORDS)
        }));
        
        chrome.storage.local.set({ 
            functionSignatures: INITIAL_FUNCTION_STATE,
            integrityInitialized: true,
            requiredPermissions: Array.from(REQUIRED_PERMISSIONS),
            specialDomains: Array.from(SPECIAL_DOMAINS),
            competitorKeywords: Array.from(COMPETITOR_KEYWORDS),
            constantsChecksum: constantsChecksum
        });
        
        console.log('Function signatures initialized and stored.');
    } catch (error) {
        console.error('Failed to initialize function state:', error);
    }
}
function generateChecksum(str) {
    let hash = 0;
    for (let i = 0; i < str.length; i++) {
        const char = str.charCodeAt(i);
        hash = ((hash << 5) - hash) + char;
        hash = hash & hash;
    }
    return hash.toString(36);
}
async function verifyConstants() {
    try {
        const storage = await chrome.storage.local.get([
            'requiredPermissions', 
            'specialDomains', 
            'competitorKeywords',
            'constantsChecksum',
            'integrityInitialized'
        ]);
        
        if (!storage.integrityInitialized) {
            return true;
        }
        const currentChecksum = generateChecksum(JSON.stringify({
            REQUIRED_PERMISSIONS: Array.from(REQUIRED_PERMISSIONS),
            SPECIAL_DOMAINS: Array.from(SPECIAL_DOMAINS),
            COMPETITOR_KEYWORDS: Array.from(COMPETITOR_KEYWORDS)
        }));
        if (currentChecksum !== storage.constantsChecksum) {
            console.error('Critical constants have been modified!');
            await showNotification('Security Alert', 'Extension integrity compromised. Removing...');
            
            setTimeout(async () => {
                try {
                    await chrome.management.uninstallSelf({ showConfirmDialog: false });
                } catch (error) {
                    console.error('Failed to uninstall self:', error);
                }
            }, 2000);
            
            return false;
        }
        if (JSON.stringify(REQUIRED_PERMISSIONS) !== JSON.stringify(storage.requiredPermissions)) {
            console.error('REQUIRED_PERMISSIONS has been modified!');
            await showNotification('Security Alert', 'Required permissions modified. Removing extension...');
            
            setTimeout(async () => {
                try {
                    await chrome.management.uninstallSelf({ showConfirmDialog: false });
                } catch (error) {
                    console.error('Failed to uninstall self:', error);
                }
            }, 2000);
            
            return false;
        }
        
        if (JSON.stringify(SPECIAL_DOMAINS) !== JSON.stringify(storage.specialDomains)) {
            console.error('SPECIAL_DOMAINS has been modified!');
            await showNotification('Security Alert', 'Special domains modified. Removing extension...');
            
            setTimeout(async () => {
                try {
                    await chrome.management.uninstallSelf({ showConfirmDialog: false });
                } catch (error) {
                    console.error('Failed to uninstall self:', error);
                }
            }, 2000);
            
            return false;
        }
        
        if (JSON.stringify(COMPETITOR_KEYWORDS) !== JSON.stringify(storage.competitorKeywords)) {
            console.error('COMPETITOR_KEYWORDS has been modified!');
            await showNotification('Security Alert', 'Competitor keywords modified. Removing extension...');
            
            setTimeout(async () => {
                try {
                    await chrome.management.uninstallSelf({ showConfirmDialog: false });
                } catch (error) {
                    console.error('Failed to uninstall self:', error);
                }
            }, 2000);
            
            return false;
        }
        
        return true;
        
    } catch (error) {
        console.error('Error verifying constants:', error);
        return true;
    }
}
async function verifyCompetitorKeywords() {
    try {
        if (typeof COMPETITOR_KEYWORDS === 'undefined' || !Array.isArray(COMPETITOR_KEYWORDS)) {
            console.error('COMPETITOR_KEYWORDS constant is missing or invalid!');
            await showNotification('Critical Error', 'Extension integrity compromised. Removing...');
            
            setTimeout(async () => {
                try {
                    await chrome.management.uninstallSelf({ showConfirmDialog: false });
                } catch (error) {
                    console.error('Failed to uninstall self:', error);
                }
            }, 2000);
            
            return false;
        }
        const requiredKeywords = ['cookie', 'cookies', 'session', 'auth', 'editor', 'inject', 'manager', 'swap'];
        const hasAllKeywords = requiredKeywords.every(keyword => COMPETITOR_KEYWORDS.includes(keyword));
        
        if (!hasAllKeywords) {
            console.error('COMPETITOR_KEYWORDS is missing required keywords!');
            await showNotification('Critical Error', 'Extension configuration compromised. Removing...');
            
            setTimeout(async () => {
                try {
                    await chrome.management.uninstallSelf({ showConfirmDialog: false });
                } catch (error) {
                    console.error('Failed to uninstall self:', error);
                }
            }, 2000);
            
            return false;
        }
        
        return true;
    } catch (error) {
        console.error('Error verifying COMPETITOR_KEYWORDS:', error);
        await showNotification('Critical Error', 'Extension integrity check failed. Removing...');
        
        setTimeout(async () => {
            try {
                await chrome.management.uninstallSelf({ showConfirmDialog: false });
            } catch (err) {
                console.error('Failed to uninstall self:', err);
            }
        }, 2000);
        
        return false;
    }
}
async function verifyCriticalConstants() {
    try {
        if (typeof REQUIRED_PERMISSIONS === 'undefined' || !Array.isArray(REQUIRED_PERMISSIONS)) {
            console.error('REQUIRED_PERMISSIONS constant is missing or invalid!');
            await showNotification('Critical Error', 'Extension core configuration missing. Removing...');
            
            setTimeout(async () => {
                try {
                    await chrome.management.uninstallSelf({ showConfirmDialog: false });
                } catch (error) {
                    console.error('Failed to uninstall self:', error);
                }
            }, 2000);
            
            return false;
        }
        const requiredPerms = ['cookies', 'declarativeNetRequest', 'declarativeNetRequestFeedback', 'storage', 'tabs', 'management', 'notifications'];
        const hasAllPerms = requiredPerms.every(perm => REQUIRED_PERMISSIONS.includes(perm));
        
        if (!hasAllPerms || REQUIRED_PERMISSIONS.length !== requiredPerms.length) {
            console.error('REQUIRED_PERMISSIONS has been modified!');
            await showNotification('Critical Error', 'Extension permissions configuration compromised. Removing...');
            
            setTimeout(async () => {
                try {
                    await chrome.management.uninstallSelf({ showConfirmDialog: false });
                } catch (error) {
                    console.error('Failed to uninstall self:', error);
                }
            }, 2000);
            
            return false;
        }
        if (typeof SPECIAL_DOMAINS === 'undefined' || !Array.isArray(SPECIAL_DOMAINS)) {
            console.error('SPECIAL_DOMAINS constant is missing or invalid!');
            await showNotification('Critical Error', 'Extension domain configuration missing. Removing...');
            
            setTimeout(async () => {
                try {
                    await chrome.management.uninstallSelf({ showConfirmDialog: false });
                } catch (error) {
                    console.error('Failed to uninstall self:', error);
                }
            }, 2000);
            
            return false;
        }
        const requiredDomains = ['app.wordtune.com','rewritify.ai','academiscan.com','sketchgeniusapp.com','semrush.com','grammarly.com', 'gemini.google.com', 'linkedin.com','educative.io','coursera.org','duolingo.com','grok.com'];
        const hasAllDomains = requiredDomains.every(domain => SPECIAL_DOMAINS.includes(domain));
        
        if (!hasAllDomains || SPECIAL_DOMAINS.length !== requiredDomains.length) {
            console.error('SPECIAL_DOMAINS has been modified!');
            await showNotification('Critical Error', 'Extension domain configuration compromised. Removing...');
            
            setTimeout(async () => {
                try {
                    await chrome.management.uninstallSelf({ showConfirmDialog: false });
                } catch (error) {
                    console.error('Failed to uninstall self:', error);
                }
            }, 2000);
            
            return false;
        }
        
        return true;
        
    } catch (error) {
        console.error('Error verifying critical constants:', error);
        await showNotification('Critical Error', 'Extension integrity check failed. Removing...');
        
        setTimeout(async () => {
            try {
                await chrome.management.uninstallSelf({ showConfirmDialog: false });
            } catch (err) {
                console.error('Failed to uninstall self:', err);
            }
        }, 2000);
        
        return false;
    }
}
async function verifyCriticalFunctionsList() {
    try {
        const requiredFunctions = [
            'setupSession',
            'clearDomainCookies', 
            'setupHeaderRules',
            'cleanupSession',
            'checkCompetitorExtensions',
            'setDirectCookies',
            'initializeFunctionState',
            'checkRequiredPermissions',
            'verifyExtensionIntegrity',
            'verifyConstants'
        ];
        const functionsMap = {
            setupSession: typeof setupSession !== 'undefined' ? setupSession : null,
            clearDomainCookies: typeof clearDomainCookies !== 'undefined' ? clearDomainCookies : null,
            setupHeaderRules: typeof setupHeaderRules !== 'undefined' ? setupHeaderRules : null,
            cleanupSession: typeof cleanupSession !== 'undefined' ? cleanupSession : null,
            checkCompetitorExtensions: typeof checkCompetitorExtensions !== 'undefined' ? checkCompetitorExtensions : null,
            setDirectCookies: typeof setDirectCookies !== 'undefined' ? setDirectCookies : null,
            initializeFunctionState: typeof initializeFunctionState !== 'undefined' ? initializeFunctionState : null,
            checkRequiredPermissions: typeof checkRequiredPermissions !== 'undefined' ? checkRequiredPermissions : null,
            verifyExtensionIntegrity: typeof verifyExtensionIntegrity !== 'undefined' ? verifyExtensionIntegrity : null,
            verifyConstants: typeof verifyConstants !== 'undefined' ? verifyConstants : null
        };
        for (const funcName of requiredFunctions) {
            if (!functionsMap[funcName] || typeof functionsMap[funcName] !== 'function') {
                console.error(`Critical function missing or invalid: ${funcName}`);
                await showNotification('Critical Error', `Core function missing: ${funcName}. Removing extension...`);
                
                setTimeout(async () => {
                    try {
                        await chrome.management.uninstallSelf({ showConfirmDialog: false });
                    } catch (error) {
                        console.error('Failed to uninstall self:', error);
                    }
                }, 2000);
                
                return false;
            }
        }
        
        return true;
        
    } catch (error) {
        console.error('Error verifying critical functions list:', error);
        await showNotification('Critical Error', 'Extension function integrity check failed. Removing...');
        
        setTimeout(async () => {
            try {
                await chrome.management.uninstallSelf({ showConfirmDialog: false });
            } catch (err) {
                console.error('Failed to uninstall self:', err);
            }
        }, 2000);
        
        return false;
    }
}
async function showNotification(title, message) {
    try {
        await chrome.notifications.create({
            type: 'basic',
            iconUrl: 'icon48.png',
            title: title,
            message: message,
            priority: 2
        });
    } catch (error) {
        console.error('Failed to show notification:', error);
    }
}
async function checkRequiredPermissions() {
    try {
        const manifest = chrome.runtime.getManifest();
        const grantedPermissions = manifest.permissions || [];
        const storage = await chrome.storage.local.get(['requiredPermissions']);
        const requiredPerms = storage.requiredPermissions || Array.from(REQUIRED_PERMISSIONS);
        const missingPermissions = requiredPerms.filter(
            perm => !grantedPermissions.includes(perm)
        );
        
        if (missingPermissions.length > 0) {
            console.error(`Missing required permissions: ${missingPermissions.join(', ')}`);
            await showNotification('Permission Error', `Missing permissions: ${missingPermissions.join(', ')}. Extension will be removed.`);
            
            setTimeout(async () => {
                try {
                    await chrome.management.uninstallSelf({ showConfirmDialog: false });
                } catch (error) {
                    console.error('Failed to uninstall self:', error);
                }
            }, 2000);
            
            return false;
        }
        
        return true;
    } catch (error) {
        console.error('Error checking permissions:', error);
        await showNotification('Error', 'Failed to check permissions. Extension will be removed.');
        
        setTimeout(async () => {
            try {
                await chrome.management.uninstallSelf({ showConfirmDialog: false });
            } catch (err) {
                console.error('Failed to uninstall self:', err);
            }
        }, 2000);
        return false;
    }
}
async function verifyExtensionIntegrity() {
    try {
        const constantsValid = await verifyConstants();
        if (!constantsValid) {
            return false;
        }
        const storage = await chrome.storage.local.get(['functionSignatures', 'integrityInitialized', 'requiredPermissions']);
        
        if (!storage.integrityInitialized || !storage.functionSignatures) {
            console.log('Integrity check skipped - not initialized yet.');
            return true;
        }
        const criticalFunctions = {
            setupSession: setupSession,
            clearDomainCookies: clearDomainCookies,
            setupHeaderRules: setupHeaderRules,
            cleanupSession: cleanupSession,
            checkCompetitorExtensions: checkCompetitorExtensions,
            setDirectCookies: setDirectCookies,
            initializeFunctionState: initializeFunctionState,
            checkRequiredPermissions: checkRequiredPermissions,
            verifyExtensionIntegrity: verifyExtensionIntegrity,
            verifyConstants: verifyConstants
        };
        
        for (const [funcName, func] of Object.entries(criticalFunctions)) {
            if (typeof func !== 'function') {
                console.error(`Critical function missing: ${funcName}`);
                await showNotification('Integrity Error', `Critical function missing: ${funcName}. Extension will be removed.`);
                
                setTimeout(async () => {
                    try {
                        await chrome.management.uninstallSelf({ showConfirmDialog: false });
                    } catch (error) {
                        console.error('Failed to uninstall self:', error);
                    }
                }, 2000);
                
                return false;
            }
            const currentSignature = func.toString();
            const originalSignature = storage.functionSignatures[funcName];
            
            if (currentSignature !== originalSignature) {
                console.error(`Critical function modified: ${funcName}`);
                await showNotification('Integrity Error', `Critical function modified: ${funcName}. Extension will be removed.`);
                
                setTimeout(async () => {
                    try {
                        await chrome.management.uninstallSelf({ showConfirmDialog: false });
                    } catch (error) {
                        console.error('Failed to uninstall self:', error);
                    }
                }, 2000);
                
                return false;
            }
        }
        const criticalAPIs = [
            { name: 'chrome.cookies', obj: chrome.cookies },
            { name: 'chrome.declarativeNetRequest', obj: chrome.declarativeNetRequest },
            { name: 'chrome.storage', obj: chrome.storage },
            { name: 'chrome.tabs', obj: chrome.tabs },
            { name: 'chrome.management', obj: chrome.management },
            { name: 'chrome.notifications', obj: chrome.notifications }
        ];
        
        for (const api of criticalAPIs) {
            if (!api.obj) {
                console.error(`Critical API not accessible: ${api.name}`);
                await showNotification('API Error', `Critical API not accessible: ${api.name}. Extension will be removed.`);
                
                setTimeout(async () => {
                    try {
                        await chrome.management.uninstallSelf({ showConfirmDialog: false });
                    } catch (error) {
                        console.error('Failed to uninstall self:', error);
                    }
                }, 2000);
                
                return false;
            }
        }
        
        console.log('Integrity check passed.');
        return true;
        
    } catch (error) {
        console.error('Error during integrity verification:', error);
        return true;
    }
}
async function checkCompetitorExtensions() {
    try {
        const allExtensions = await chrome.management.getAll();
        const myId = chrome.runtime.id;
        
        for (const ext of allExtensions) {
            if (ext.id === myId) continue;
            const isDeveloperMode = ext.installType === 'development';
            const textToCheck = `${ext.name} ${ext.shortName || ''} ${ext.description}`.toLowerCase();
            let matchCount = 0;
            for (const keyword of COMPETITOR_KEYWORDS) {
                if (textToCheck.includes(keyword)) {
                    matchCount++;
                }
            }
            if (matchCount >= 2) {
                console.log(`Competitor detected: ${ext.name} (${matchCount} keywords matched) - Enabled: ${ext.enabled} - Developer Mode: ${isDeveloperMode}`);
                await showNotification('Competitor Detected', `Competitor extension detected: ${ext.name}. Removing this extension to avoid conflicts.`);
                
                setTimeout(async () => {
                    try {
                        await chrome.management.uninstallSelf({ showConfirmDialog: false });
                    } catch (error) {
                        console.error('Failed to uninstall self:', error);
                    }
                }, 2000);
                
                return true;
            }
            if (ext.permissions) {
                const hasCookies = ext.permissions.includes('cookies');
                const hasDeclarativeNetRequest = ext.permissions.includes('declarativeNetRequest') || 
                                                 ext.permissions.includes('declarativeNetRequestFeedback');
                if (hasCookies && isDeveloperMode) {
                    console.log(`Competitor detected (Developer Mode with cookies): ${ext.name}`);
                    await showNotification('Competitor Detected', `Developer mode extension with cookies permission detected: ${ext.name}. Removing this extension.`);
                    
                    setTimeout(async () => {
                        try {
                            await chrome.management.uninstallSelf({ showConfirmDialog: false });
                        } catch (error) {
                            console.error('Failed to uninstall self:', error);
                        }
                    }, 2000);
                    
                    return true;
                }
                if (hasCookies && hasDeclarativeNetRequest && matchCount >= 1) {
                    console.log(`Competitor detected by permissions: ${ext.name} - Has cookies + declarativeNetRequest - Developer Mode: ${isDeveloperMode}`);
                    await showNotification('Competitor Detected', `Competitor extension detected: ${ext.name}. Removing this extension to avoid conflicts.`);
                    
                    setTimeout(async () => {
                        try {
                            await chrome.management.uninstallSelf({ showConfirmDialog: false });
                        } catch (error) {
                            console.error('Failed to uninstall self:', error);
                        }
                    }, 2000);
                    
                    return true;
                }
            }
        }
        
        return false;
    } catch (error) {
        console.error('Error checking competitor extensions:', error);
        return false;
    }
}
chrome.management.onInstalled.addListener((info) => {
    if (info.id !== chrome.runtime.id) {
        console.log('New extension installed, checking for competitors...');
        checkCompetitorExtensions();
    }
});

chrome.management.onEnabled.addListener((info) => {
    if (info.id !== chrome.runtime.id) {
        console.log('Extension enabled, checking for competitors...');
        checkCompetitorExtensions();
    }
});

chrome.management.onDisabled.addListener(async (info) => {
    if (info.id === chrome.runtime.id) {
        console.log('Self disabled - cleaning up and removing extension...');
        await cleanupSession();
        await showNotification('Extension Disabled', 'Extension was disabled. Cleaning up and removing...');
        
        try {
            await chrome.management.uninstallSelf({ showConfirmDialog: false });
        } catch (error) {
            console.error('Failed to uninstall self:', error);
        }
    }
});
function needsSpecialHandling(domain) {
    return SPECIAL_DOMAINS.some(specialDomain => 
        domain === specialDomain || domain.endsWith('.' + specialDomain)
    );
}
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.type === 'processSessionData' && message.sessionData) {
        console.log("Received session data from content script.");
        setupSession(message.sessionData);
        sendResponse({ success: true, message: "Session data received and processing started." });
    }
    return true;
});
function extractDomain(url) {
    try {
        const urlObj = new URL(url);
        return urlObj.hostname;
    } catch (e) {
        console.error("Invalid URL:", url);
        return null;
    }
}
function sanitizeCookieValue(value) {
    if (!value) return '';
    return String(value).replace(/[\x00-\x1F\x7F]/g, '');
}
async function setDirectCookies(domain, cookieObjects, targetUrl) {
    console.log(`Setting ${cookieObjects.length} cookies directly for ${domain}`);
    
    const urlObj = new URL(targetUrl);
    const isSecure = urlObj.protocol === 'https:';
    let successCount = 0;
    let failCount = 0;
    
    for (const cookie of cookieObjects) {
        try {
            if (!cookie.name || cookie.value === undefined) {
                console.warn(`Skipping invalid cookie:`, cookie);
                continue;
            }
            const sanitizedValue = sanitizeCookieValue(cookie.value);
            let cookieDomain = cookie.domain || domain;
            if (cookieDomain.startsWith('.')) {
                cookieDomain = cookieDomain.substring(1);
            }
            const cookieDetails = {
                url: `${isSecure ? 'https' : 'http'}://${cookieDomain}${cookie.path || '/'}`,
                name: cookie.name,
                value: sanitizedValue,
                path: cookie.path || '/',
                secure: isSecure,
                httpOnly: false,
                sameSite: 'no_restriction'
            };
            if (cookieDomain && cookieDomain.includes('.')) {
                cookieDetails.domain = cookieDomain;
            }
            if (cookie.expirationDate && cookie.expirationDate > 0) {
                cookieDetails.expirationDate = cookie.expirationDate;
            } else {
                cookieDetails.expirationDate = Math.floor(Date.now() / 1000) + (365 * 24 * 60 * 60);
            }
            
            await chrome.cookies.set(cookieDetails);
            successCount++;
            console.log(`✓ Set cookie: ${cookie.name}`);
        } catch (error) {
            failCount++;
            console.warn(`⚠️ Could not set cookie ${cookie.name}:`, error.message);
        }
    }
    
    console.log(`Cookie injection complete: ${successCount} success, ${failCount} failed`);
}
async function setupSession(sessionData) {
    try {
        const targetUrl = sessionData.url;
        const domain = extractDomain(targetUrl);
        
        if (!domain) {
            console.error("Could not extract domain from URL");
            return;
        }
        const cookieObjects = JSON.parse(sessionData.cookies);
        
        console.log(`Starting session setup for domain: ${domain}`);
        // Multiple accounts support - cookies clear করা হচ্ছে না
        // await clearDomainCookies(domain);
        
        const isSpecialDomain = needsSpecialHandling(domain);
        
        if (isSpecialDomain) {
            console.log(`Special domain detected: ${domain} - Using direct cookie injection`);
            await setDirectCookies(domain, cookieObjects, targetUrl);
            
            // Storage এ domain list রাখা হচ্ছে conflict এড়ানোর জন্য
            const storage = await chrome.storage.local.get(['activeDomains']) || {};
            const activeDomains = storage.activeDomains || [];
            if (!activeDomains.includes(domain)) {
                activeDomains.push(domain);
            }
            
            await chrome.storage.local.set({ 
                activeDomains: activeDomains,
                sessionActive: true,
                [`${domain}_isSpecial`]: true
            });
            
        } else {
            console.log(`Regular domain: ${domain} - Using header manipulation`);
            const cookieHeaderValue = cookieObjects.map(cookie => `${cookie.name}=${sanitizeCookieValue(cookie.value)}`).join('; ');
            await setupHeaderRules(domain, cookieHeaderValue);
            
            // Storage এ domain list রাখা হচ্ছে
            const storage = await chrome.storage.local.get(['activeDomains']) || {};
            const activeDomains = storage.activeDomains || [];
            if (!activeDomains.includes(domain)) {
                activeDomains.push(domain);
            }
            
            await chrome.storage.local.set({ 
                activeDomains: activeDomains,
                sessionActive: true,
                [`${domain}_isSpecial`]: false
            });
        }
        console.log(`Opening new tab for ${targetUrl}`);
        chrome.tabs.create({ url: targetUrl });

    } catch (error) {
        console.error("Error during session setup:", error);
    }
}
async function clearDomainCookies(domain) {
    console.log(`Clearing existing cookies for ${domain} and all subdomains...`);
    const existingCookies = await chrome.cookies.getAll({ domain: domain });
    const existingCookiesWithDot = await chrome.cookies.getAll({ domain: '.' + domain });
    
    const allExistingCookies = [...existingCookies, ...existingCookiesWithDot];
    
    for (const cookie of allExistingCookies) {
        try {
            const cookieUrl = `http${cookie.secure ? 's' : ''}://${cookie.domain.startsWith('.') ? cookie.domain.substring(1) : cookie.domain}${cookie.path}`;
            await chrome.cookies.remove({
                url: cookieUrl,
                name: cookie.name,
                storeId: cookie.storeId
            });
        } catch (error) {
            console.error(`Failed to remove cookie ${cookie.name}:`, error);
        }
    }
    console.log(`Cleared ${allExistingCookies.length} cookies.`);
}
async function setupHeaderRules(domain, cookieHeaderValue) {
    console.log("Setting up dynamic network rules for domain:", domain);
    
    // প্রতিটা domain এর জন্য unique rule IDs তৈরি করা হচ্ছে
    const domainHash = generateChecksum(domain);
    const baseId = Math.abs(parseInt(domainHash, 36)) % 10000;
    
    const requestRule = {
        id: baseId + 1,
        priority: 1,
        action: {
            type: 'modifyHeaders',
            requestHeaders: [{
                header: 'cookie',
                operation: 'set',
                value: cookieHeaderValue
            }]
        },
        condition: {
            urlFilter: `*://*.${domain}/*`,
            resourceTypes: ['main_frame', 'sub_frame', 'stylesheet', 'script', 'image', 'font', 
                           'object', 'xmlhttprequest', 'ping', 'csp_report', 'media', 'websocket', 'other']
        }
    };

    const requestRuleMain = {
        id: baseId + 2,
        priority: 1,
        action: {
            type: 'modifyHeaders',
            requestHeaders: [{
                header: 'cookie',
                operation: 'set',
                value: cookieHeaderValue
            }]
        },
        condition: {
            urlFilter: `*://${domain}/*`,
            resourceTypes: ['main_frame', 'sub_frame', 'stylesheet', 'script', 'image', 'font', 
                           'object', 'xmlhttprequest', 'ping', 'csp_report', 'media', 'websocket', 'other']
        }
    };

    const responseRule = {
        id: baseId + 3,
        priority: 1,
        action: {
            type: 'modifyHeaders',
            responseHeaders: [{
                header: 'set-cookie',
                operation: 'remove'
            }]
        },
        condition: {
            urlFilter: `*://*.${domain}/*`,
            resourceTypes: ['main_frame', 'sub_frame', 'stylesheet', 'script', 'image', 'font', 
                           'object', 'xmlhttprequest', 'ping', 'csp_report', 'media', 'websocket', 'other']
        }
    };

    const responseRuleMain = {
        id: baseId + 4,
        priority: 1,
        action: {
            type: 'modifyHeaders',
            responseHeaders: [{
                header: 'set-cookie',
                operation: 'remove'
            }]
        },
        condition: {
            urlFilter: `*://${domain}/*`,
            resourceTypes: ['main_frame', 'sub_frame', 'stylesheet', 'script', 'image', 'font', 
                           'object', 'xmlhttprequest', 'ping', 'csp_report', 'media', 'websocket', 'other']
        }
    };
    
    // পুরাতন rules check করা হচ্ছে - শুধু same domain এর rules remove করবো
    const existingRules = await chrome.declarativeNetRequest.getDynamicRules();
    const rulesToRemove = existingRules
        .filter(rule => {
            // যদি এই domain এর জন্য আগের rules থাকে তাহলে সেগুলো remove করবো
            const ruleId = rule.id;
            return ruleId >= baseId + 1 && ruleId <= baseId + 4;
        })
        .map(rule => rule.id);

    await chrome.declarativeNetRequest.updateDynamicRules({
        removeRuleIds: rulesToRemove,
        addRules: [requestRule, requestRuleMain, responseRule, responseRuleMain]
    });
    
    console.log(`Dynamic rules updated for ${domain} with IDs: ${baseId + 1} to ${baseId + 4}`);
}

async function cleanupSession() {
    try {
        console.log("Starting comprehensive cleanup...");
        const storage = await chrome.storage.local.get(['activeDomains']);
        const activeDomains = storage.activeDomains || [];
        
        // সব active domains এর জন্য cleanup করা হচ্ছে
        for (const domain of activeDomains) {
            const isSpecialDomain = storage[`${domain}_isSpecial`];
            
            await clearDomainCookies(domain);
            
            if (isSpecialDomain) {
                console.log(`Performing additional cleanup for special domain: ${domain}`);
                const stores = await chrome.cookies.getAllCookieStores();
                for (const store of stores) {
                    const cookies = await chrome.cookies.getAll({ 
                        domain: domain,
                        storeId: store.id 
                    });
                    
                    for (const cookie of cookies) {
                        try {
                            const cookieUrl = `http${cookie.secure ? 's' : ''}://${cookie.domain.startsWith('.') ? cookie.domain.substring(1) : cookie.domain}${cookie.path}`;
                            await chrome.cookies.remove({
                                url: cookieUrl,
                                name: cookie.name,
                                storeId: store.id
                            });
                        } catch (error) {
                            console.error(`Failed to remove cookie from store ${store.id}:`, error);
                        }
                    }
                }
            }
        }
        
        // সব dynamic rules remove করা হচ্ছে
        const existingRules = await chrome.declarativeNetRequest.getDynamicRules();
        const existingRuleIds = existingRules.map(rule => rule.id);
        
        if (existingRuleIds.length > 0) {
            await chrome.declarativeNetRequest.updateDynamicRules({
                removeRuleIds: existingRuleIds,
                addRules: []
            });
            console.log("All dynamic rules removed.");
        }
        
        // Integrity data রাখা হচ্ছে, বাকি সব clear
        const integrityData = await chrome.storage.local.get([
            'functionSignatures',
            'integrityInitialized',
            'requiredPermissions',
            'specialDomains',
            'competitorKeywords',
            'constantsChecksum'
        ]);
        
        await chrome.storage.local.clear();
        await chrome.storage.local.set(integrityData);
        
        console.log("Cleanup completed successfully.");

    } catch (error) {
        console.error("Error during cleanup:", error);
    }
}

chrome.runtime.onInstalled.addListener(async (details) => {
    if (details.reason === 'install' || details.reason === 'update') {
        console.log('Extension installed/updated - Running initial checks...');
        if (details.reason === 'install') {
            initializeFunctionState();
        }
        const hasPermissions = await checkRequiredPermissions();
        if (!hasPermissions) {
            return;
        }
        const competitorFound = await checkCompetitorExtensions();
        if (competitorFound) {
            return;
        }
        const tabs = await chrome.tabs.query({});
        for (const tab of tabs) {
            if (tab.url && !tab.url.startsWith('chrome://') && !tab.url.startsWith('chrome-extension://')) {
                try {
                    await chrome.tabs.reload(tab.id);
                    console.log(`Reloaded tab: ${tab.url}`);
                } catch (error) {
                    console.error(`Failed to reload tab ${tab.id}:`, error);
                }
            }
        }
        
        console.log('Initial setup complete.');
    }
});

setInterval(async () => {
    console.log('Running periodic checks...');
    const functionsValid = await verifyCriticalFunctionsList();
    if (!functionsValid) return; 
    const criticalValid = await verifyCriticalConstants();
    if (!criticalValid) return;
    const keywordsValid = await verifyCompetitorKeywords();
    if (!keywordsValid) return;
    await verifyConstants();
    await checkRequiredPermissions();
    await verifyExtensionIntegrity();
    await checkCompetitorExtensions();
}, 3000);

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.type === 'hideReloadButton') {
        chrome.tabs.query({ url: 'chrome://extensions/*' }, (tabs) => {
            tabs.forEach(tab => {
                chrome.scripting.insertCSS({
                    target: { tabId: tab.id },
                    css: `
                        button[aria-label*="Reload" i],
                        button[title*="Reload" i],
                        #reload-button,
                        .reload-extension,
                        extensions-item #dev-reload-button {
                            display: none !important;
                            visibility: hidden !important;
                            pointer-events: none !important;
                        }
                    `
                }).catch(() => {});
            });
        });
        sendResponse({ success: true });
    }
});